package dz.masajid.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import java.util.*;

public class AdhanReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    String prayer=intent.getStringExtra("prayer");
    if(prayer==null) prayer="الصلاة";
    if(Build.VERSION.SDK_INT>=26){
      NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
      nm.createNotificationChannel(new NotificationChannel("adhan","الآذان",NotificationManager.IMPORTANCE_HIGH));
      Notification n=new Notification.Builder(context,"adhan")
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("حان وقت صلاة "+prayer)
        .setContentText("حان الآن وقت صلاة "+prayer)
        .setAutoCancel(true).build();
      nm.notify((int)(System.currentTimeMillis()%100000),n);
    }
    final TextToSpeech[] holder=new TextToSpeech[1];
    holder[0]=new TextToSpeech(context, status -> {
      if(status==TextToSpeech.SUCCESS){
        holder[0].setLanguage(new Locale("ar"));
        holder[0].speak("الله أكبر، حان الآن وقت صلاة "+prayer, TextToSpeech.QUEUE_FLUSH, null, "adhan");
      }
    });
  }
}
