# MasajidDZ — Build APK from phone

1. Create a GitHub repository and upload all files in this folder.
2. Open the **Actions** tab.
3. Select **Build APK** and tap **Run workflow**.
4. When finished, open the workflow run and download **MasajidDZ-debug-apk** from Artifacts.
5. Extract the downloaded artifact and install `app-debug.apk`.
